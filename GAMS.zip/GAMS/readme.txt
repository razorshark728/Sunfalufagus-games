For this to work you need to put the GAMS folder(the one with gams.html in it) in this file path[My PC/Windows (C:)]
Copy the GAMS.html to your desktop for easy access.

No support for Linux or mobile devices.

This project is constantly developing so make sure to return to the GitHub page every once in a while to stay updated with the latest games.